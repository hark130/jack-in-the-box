"""Connecting Jackbox Games to the OpenAI API in Python.

Usage: jitb --help
"""
