"""Automates system control of Linux daemons using subprocess.

This module defines functions dedicated to wrapping and/or automating the execution of commands,
through subprocess, to control the systemd system and service manager (see: systemctl).

    Typical usage example:

    from hobo.daemon_automation import reload_daemon, start_daemon, stop_daemon

    start_daemon('sshd')   # sudo systemctl sshd start
    reload_daemon('sshd')  # sudo systemctl sshd reload
    stop_daemon('sshd')    # sudo systemctl sshd stop
"""

# Standard Imports
# Third Party Imports
# Local Imports
from hobo.common_automation import execute_systemctl_cmd
from hobo.validation import validate_type


def reload_daemon(daemon_name: str) -> None:
    """Executes `sudo systemctl reload daemon_name`.

    Calls _execute_systemctl_daemon_cmd() under the hood and does not validate daemon_name.

    Args:
        daemon_name: The name of the systemd service to reload.

    Raises:
        RuntimeError: Command execution fails or errors.
    """
    # LOCAL VARIABLES
    # (stdout, stderr) from execute_systemctl_cmd() return value
    _, std_error = execute_systemctl_cmd(daemon_name, 'reload', as_root=True)
    # Check output
    if std_error:
        raise RuntimeError(f'The systemctl command to reload {daemon_name} '
                           f'has failed with {std_error}')


def start_daemon(daemon_name: str) -> None:
    """Executes `sudo systemctl start daemon_name`.

    Calls _execute_systemctl_daemon_cmd() under the hood and does not validate daemon_name.

    Args:
        daemon_name: The name of the systemd service to start.

    Raises:
        RuntimeErrorr: Command execution fails or errors.
    """
    # LOCAL VARIABLES
    # (stdout, stderr) from execute_systemctl_cmd() return value
    _, std_error = execute_systemctl_cmd(daemon_name, 'start', as_root=True)
    # Check output
    if std_error:
        raise RuntimeError(f'The systemctl command to start {daemon_name} '
                           f'has failed with {std_error}')


def stop_daemon(daemon_name: str, report_errors: bool = True) -> None:
    """Executes `sudo systemctl stop daemon_name`.

    Calls _execute_systemctl_daemon_cmd() under the hood and does not validate daemon_name.

    Args:
        daemon_name: The name of the systemd service to stop.
        report_errors: Optional; If True, raises exceptions if the systemctl outputs anything to
            stderr.

    Raises:
        RuntimeError: Command execution fails or errors.
        TypeError: report_errors is not a bool.
    """
    # INPUT VALIDATION
    validate_type(report_errors, 'report_errors', bool)

    # LOCAL VARIABLES
    # (stdout, stderr) from execute_systemctl_cmd() return value
    _, std_error = execute_systemctl_cmd(daemon_name, 'stop', as_root=True)

    # CHECK OUTPUT
    if std_error and report_errors:
        raise RuntimeError(f'The systemctl command to stop {daemon_name} '
                           f'has failed with {std_error}')
