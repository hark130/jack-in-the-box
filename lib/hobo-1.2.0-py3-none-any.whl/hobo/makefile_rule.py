"""Defines the MakefileRule class.

Defines the MakefileRule class to help abstract the validation and execution of Makefile rules.

    Typical usage example:

    from hobo.makefile_rule import MakefileRule

    clean_rule = MakefileRule(makefile_filename='Makefile', makefile_rule='clean')
    clean_rule.verify()
    clean_rule.execute()
"""

# Standard Imports
import os
# Third Party Imports
# Local Imports
from hobo.disk_operations import validate_file
from hobo.misc import check_euid, detect_clockskew_warning
from hobo.subprocess_wrapper import execute_subprocess_cmd
from hobo.validation import validate_list, validate_string, validate_type


class MakefileRule:
    """Defines Makefile rule details.

    Defines the requirements and details of one Makefile rule.  Provides functionality to
    validate, verify and execute, using subprocess, that Makefile rule.

    Attributes:
        None
    """

    # CORE CLASS METHODS
    # Methods listed in suggested call, and then alphabetical, order

    # pylint: disable=too-many-arguments
    # Pylint Note: I made a specific design decision to include *all* of the necessary arguments
    #   in the constructor instead of doling out arguments to the subsequent methods (like moving
    #   the verify_rule argument into the verify() method, for instance).  I did so in an attempt
    #   to minimize how knowledge the hobo.makefile_automation functions would need to know about
    #   verification, build requirements, etc.  This way, the caller (who should have an intimate
    #   understanding of what's required for a given Makefile rule to be successfully executed)
    #   defines the necessary behavior.  All the hobo.makefile_automation functions have to do
    #   is call verify() and execute().  I say, 'let it ride'.
    def __init__(self, makefile_filename: str, makefile_rule: str, as_root: bool = False,
                 options: list = None, verify_rule: bool = True, ) -> None:
        """MakefileRule ctor.

        Takes all configurations necessary to validate, verify and execute a single Makefile rule
        using subprocess.

        Args:
            makefile_filename: The relative or absolute filename to the Makefile being used.
            makefile_rule: The name of the Makefile rule being verified and executed.
            as_root: Optional; Executes this rule with root privileges.
            options: Optional; List of non-empty strings to append to the rule during execution.
            verify_rule: Optional; Verifies makefile_rule exists within makefile_filename.

        Raises:
            None
        """
        # ATTRIBUTES
        self._makefile_filename = makefile_filename  # Relative or absolute makefile filename
        self._makefile_rule = makefile_rule          # Makefile rule name
        self._as_root = as_root                      # Execute with root privileges
        # Options to pass to the rule
        if isinstance(options, list):
            self._options = options
        else:
            self._options = []
        self._verify_rule = verify_rule              # Verify rule exists in the makefile filename
        self._is_verified = False                    # The verify() method has been called
    # pylint: enable=too-many-arguments

    def verify(self) -> None:
        """Verifies the input and environment.

        Validates all data provided by the caller.  Also verifies the environment as necessary.
        Set the _is_verified attribute to True after calling this method to avoid
        unnecessary duplication.

        Args:
            None

        Raises:
            FileNotFoundError: Makefile doesn't exist.
            OSError: Makefile is not a file.
            RuntimeError: 'root' privileges are required but missing or the rule is missing from
                the Makefile.
            TypeError: Invalid data type.
            ValueError: Invalid value.
        """
        self._validate_input()
        self._verify_environment()
        self._is_verified = True  # If you made it here, you're good

    def execute(self, ignore_clockskew: bool = True) -> None:
        """Executes the validated Makefile rule.

        Validates the attributes and environment, if not already done so, and executes the
        Makefile rule provided.

        Args:
            ignore_clockskew: Optional; Ignores any 'clock skew detected' or 'modification time'
                errors detected in Makefiles error output.

        Raises:
            see: verify() method
            RuntimeError: Makefile rule provided errors
        """
        # INPUT VALIDATION
        if not self._is_verified:
            self.verify()

        # EXECUTE
        self._execute(ignore_clockskew=ignore_clockskew)

    # CLASS HELPER METHODS
    # Methods listed in alphabetical order
    def _execute(self, ignore_clockskew: bool = True) -> None:
        """Executes the Makefile rule.

        Executes the Makefile rule through subprocess.  Does not validate input or the
        environment.

        Args:
            ignore_clockskew: Optional; Ignores any 'clock skew detected' or 'modification time'
                errors detected in Makefile's error output.

        Raises:
            RuntimeError: Makefile rule failed or provided errors.
        """
        # LOCAL VARIABLES
        rule_cmd_list = ['make']  # Make rule command syntax
        use_this_dir = ''         # Directory that holds the Makefile
        error_string = ''         # Format the RuntimeError string here
        exec_error = False        # Error detected in execution

        # PREPARE SUBPROCESS ARGS
        if self._as_root:
            rule_cmd_list = ['sudo'] + rule_cmd_list
        rule_cmd_list += [self._makefile_rule]
        if self._options:
            rule_cmd_list += self._options
        use_this_dir = os.path.split(self._makefile_filename)[0]

        # EXECUTE COMMAND LIST
        try:
            _, stderr = execute_subprocess_cmd(rule_cmd_list,
                                               set_cwd=use_this_dir)
        except RuntimeError as err:
            raise RuntimeError(f'Makefile rule "{self._makefile_rule}" failed with {str(err)}')
        else:
            # Check for errors
            if stderr:
                if ignore_clockskew:
                    if not detect_clockskew_warning(stderr.lower()):
                        exec_error = True
                else:
                    exec_error = True
            # Form and raise exception
            if exec_error:
                error_string = f'Makefile rule "{self._makefile_rule}" encountered errors:\n' + \
                               f'{stderr}\n' + \
                               'Replicate these errors with:\n' + \
                               f"{' '.join(rule_cmd_list)}"
                if self._options:
                    error_string = \
                        error_string + \
                        '\nNOTE: When executing the command, consider ' + \
                        'the following:' + \
                        '\n\tWhen referencing Makefile rules, ' + \
                        'subprocess does not need to escape the $ but you ' + \
                        'might (e.g., OBJECT_LIST=\\$(HOBO_OBJECTS) ' + \
                        '\n\tWhen overriding Makefile variables, subprocess ' + \
                        'does not need to encapsulate multiple arguments in ' + \
                        'quotes but you might ' + \
                        '(e.g., CLI_FLAGS="-DHOBOWATCH -DHOBO_STDIO -g"'
                raise RuntimeError(error_string)

    def _validate_input(self) -> None:
        """Validates user input.

        Validates all of the attributes provided by the user in the constructor.

        Args:
            None

        Raises:
            TypeError: Invalid data type.
            ValueError: Invalid value.
        """
        # INPUT VALIDATION
        # makefile_filename
        validate_string(self._makefile_filename, 'makefile_filename')
        # makefile_rule
        validate_string(self._makefile_rule, 'makefile_rule')
        # as_root
        validate_type(self._as_root, 'as_root', bool)
        # options
        validate_list(self._options, 'options', can_be_empty=True)
        for entry in self._options:
            validate_string(entry, 'options entry')
        # verify_rule
        validate_type(self._verify_rule, 'verify_rule', bool)

    def _verify_environment(self) -> None:
        """Verifies the input and environment.

        Verifies all data provided by the caller.  Also validates the environment as necessary.
        Set the _is_verified attribute to True after calling this method to avoid
        unnecessary duplication.  Finally, this method assumes that _validate_input() has already
        been called.

        Args:
            None

        Raises:
            FileNotFoundError: Makefile doesn't exist.
            OSError: Makefile is not a file.
            RuntimeError: root privileges are required but missing or the rule is missing from
                the Makefile.
            TypeError: Invalid data type.
            ValueError: Invalid value.
        """
        # ENVIRONMENT VALIDATION
        # makefile_filename
        validate_file(self._makefile_filename, 'makefile_filename')
        # Got root?
        self._verify_root()
        # Verify rule exists in the makefile
        self._verify_rule_exists()

    def _verify_root(self) -> None:
        """Verifies root privileges.

        If configured, verifies the calling code has root privileges.  This method assumes that
        _validate_input() has already been called.

        Args:
            None

        Raises:
            RuntimeError: root privileges are required but missing.
        """
        # Got root?
        if self._as_root and not check_euid():
            raise RuntimeError(
                f'The makefile rule "{self._makefile_rule}" requires root privileges')

    def _verify_rule_exists(self) -> None:
        """Verifies rule exists in Makefile.

        If configured, searches the Makefile for the rule provided.  This method assumes that
        _validate_input() has already been called.

        Args:
            None

        Raises:
            RuntimeError: Unable to locate the mandatory rule in the Makefile.
        """
        if self._verify_rule:
            with open(self._makefile_filename, 'r') as in_file:
                if self._makefile_rule + ':' not in in_file.read():
                    raise RuntimeError(
                        f'Unable to find {self._makefile_rule} in {self._makefile_filename}')
