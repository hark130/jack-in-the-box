"""Holds networking functions.

This module contains network functionality to include verifying IPv4 addresses.

    Typical usage example:

    from hobo.network import is_valid_ipv4_addr

    is_valid_ipv4_addr('127.0.0.1')
"""

# Standard Imports
from ipaddress import AddressValueError, IPv4Address
import os
# Third Party Imports
# Local Imports
from hobo.subprocess_wrapper import get_subprocess_cmd_exit


def is_valid_ipv4_addr(ip_addr: str) -> bool:
    """Verifies an IP address is a valid IPv4 string.

    Verifies ip_addr is a valid IPv4 string. This function does not contain input validation and
    calls ipaddress.IPv4Address() under the hood.

    Args:
        ip_addr: The string to validate.

    Returns:
        True if ip_addr is a valid IPv4 string, False otherwise.

    Raises:
        None
    """
    # Local Variables
    is_valid = True

    try:
        IPv4Address(ip_addr)
    except AddressValueError:
        is_valid = False

    return is_valid


def verify_ip_connectivity(ip_addr: str) -> None:
    """Verifies if an IP address is available for connectivity.

    Verifies if ip_addr is available for connectivity. This function does not validate the type of
    ip_addr but calls is_valid_ipv4_addr() under the hood to check if it's a valid IPv4 string.

    Args:
        ip_addr: IP address to verify.

    Returns:
        None

    Raises:
        RuntimeError: Unable to contact ip_addr.
        ValueError: Invalid IPv4 address given.
    """
    if is_valid_ipv4_addr(ip_addr):
        param = '-c'

        if os.name == 'nt':  # Windows
            param = '-n'

        command = ['ping', param, '2', ip_addr]

        if get_subprocess_cmd_exit(command) != 0:
            raise RuntimeError(f'Unable to contact {ip_addr}')
    else:
        raise ValueError('Invalid IPv4 address')
