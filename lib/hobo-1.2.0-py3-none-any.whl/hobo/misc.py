"""Holds miscellaneous functions.

This module contains functionality for checking system privilege levels, extricating numbers,
finding substrings, printing messages, and replacing characters. Functions found here may be
extricated into new modules.

    Typical usage example:

    from hobo.misc import (check_euid, extricate_numbers, find_needle_range, print_banner
                            print_exception, replace_chars)

    get_root = check_euid()
    detect_clockskew_warning(err)
    extricate_numbers('This has more than 1 number because it has 2.')
    find_needle_range('What is the game?', 'the', 'game')
    print_banner('Hello World', '-', 2)
    print_exception(err)
    replace_chars(['t', 'o'], 'Check this out.', 'f')
    safe_call(do_it, (1, 2), {'silent':True}, sys.stderr)
"""

# Developer Note: Keep an open mind to transitioning expanded functionality into separate modules.
#   This may be a catch-all module but functions found here may need to be extricated into new
#   modules.

# Standard Imports
import io
import os
import sys
import types
# Third Party Imports
# Local Imports
# pylint: disable=import-error
from hobo.validation import validate_callable, validate_list, validate_string, validate_type
# pylint: enable=import-error


def check_euid() -> bool:
    """Checks for Linux root level privileges.

    Determines level privileges by the current process's effective user ID.

    Args:
        None

    Returns:
        True if root, False otherwise.

    Raises:
        None
    """
    # LOCAL VARIABLES
    got_root = True  # Effective user identification of 0

    # CHECK IT
    if os.geteuid() != 0:
        got_root = False

    # DONE
    return got_root


def detect_clockskew_warning(exception: str, silent: bool = False) -> bool:
    """Detects makefile clock skew exceptions.

    This function parses the error strings and uses 'clock skew detected' and
    'modification time' to detect clockskew errors.  If an error is detected, this function
    prints a notice to stdout unless 'silent' is True.

    Args:
        exception: std_err output from the execution of a Makefile rule.
        silent: Optional; If True, silences function output.

    Returns:
        True if clock skew warning detected, False otherwise.

    Raises:
        TypeError: Invalid data type.
    """
    # Developer Note:
    #   Tried using a regex parser here. Even though the regex was valid and verified, it
    # returned 0 matches for the modification time string. This was simplified to just
    # search for keyword values within the error string.

    # INPUT VALIDATION
    # exception
    validate_string(exception, 'exception', can_be_empty=True)
    # silent
    validate_type(silent, 'silent', bool)

    # CHECK FOR CLOCK SKEW
    ignore = False  # Return value for the function
    # Split the string out into individual lines. Remove empty strings.
    exceptions = list(filter(None, exception.split('\n')))
    # Make sure that we are only returning true if the 2 clock skew warnings are present in the
    # string
    if len(exceptions) == 2:
        found_csd = False
        found_mt = False
        if 'clock skew detected' in exceptions[0] or 'clock skew detected' in exceptions[1]:
            found_csd = True
        if 'modification time' in exceptions[0] or 'modification time' in exceptions[1]:
            found_mt = True
        ignore = found_csd and found_mt
    # Even though we always see the 2 warnings output together, do due diligence to ensure that
    # we don't return a false negative based on assumptions that they will always be output
    # together
    elif len(exceptions) == 1:
        if 'clock skew detected' in exception \
                or 'modification time' in exception:
            ignore = True
    # Just let the user know that you helped them out ;)
    if ignore and not silent:
        print('Notice: Ignoring clock skew warning\n')

    return ignore


def extricate_numbers(string: str) -> list:
    """Extricates any digits from string and returns them in a list.

    Empty strings are ignored and if no digits are found an empty list is returned.

    Args:
        string: The string to extract numbers from.

    Returns:
        A list of converted integers or an empty list if no digits were found.

    Raises:
        TypeError: string is not a string.
    """
    # LOCAL VARIABLES
    converted_list = []  # Digit sub-strings converted to integers
    temp_num = ''        # Digits extracted from each word in string

    # INPUT VALIDATION
    # haystack
    validate_string(string, 'string', can_be_empty=True)

    # PARSE IT
    for word in string.split():
        temp_num = ''.join([num for num in word if num.isdigit()])
        if temp_num:
            converted_list.append(int(temp_num))

    # DONE
    return converted_list


def find_needle_range(haystack: str, needle_start: str, needle_stop: str) -> str:
    """Finds and returns a sub-string "needle" in a "haystack".

    Looks for substring, starting with needle_start and ending with needle_stop, within haystack.
    The function returns the first occurrence of the needle substring.

    Args:
        haystack: The string to search.
        needle_start: The beginning of the needle.
        needle_stop: The inclusive end of the needle.

    Returns:
        A string containing the needle substring or an empty string if the needle wasn't found.

    Raises:
        TypeError: Invalid data type.
        ValueError: Empty parameter.
    """
    # LOCAL VARIABLES
    full_needle = ''          # Full substring found in haystack, if any
    temp_haystack = haystack  # Consume this string to find the needle
    start_index = 0           # Beginning index of needle_start
    stop_index = 0            # Ending index of needle_stop

    # INPUT VALIDATION
    # haystack
    validate_string(haystack, 'haystack')
    # needle_start
    validate_string(needle_start, 'needle_start')
    # needle_stop
    validate_string(needle_stop, 'needle_stop')

    # SEARCH
    while True:
        start_index = temp_haystack.find(needle_start)
        if start_index < 0:
            break  # Didn't find the beginning of the needle
        temp_haystack = temp_haystack[start_index:]
        stop_index = temp_haystack.find(needle_stop)
        if stop_index < 0:
            break  # Didn't find the end of the needle
        temp_haystack = temp_haystack[:stop_index + len(needle_stop)]
        full_needle = temp_haystack
        break  # If we made it here, we got it

    # DONE
    return full_needle


def print_banner(message: str, delim_char: str = '#', thickness: int = 1) -> None:
    """Prints a message wrapped in a banner of characters.

    delim_char is used to form the banner. If delim_char is longer than one character, it will be
    truncated. A blank line is printed after the banner.

    Args:
        message: The string to print.
        delim_char: Optional; The character used to form banner.
        thickness: Optional; The width of the banner's frame.

    Raises:
        TypeError: Invalid data type.
        ValueError: Empty parameter or invalid thickness value.
    """
    # LOCAL VARIABLES
    actual_delim = ''  # Printed character to form the banner
    banner_len = 0     # Total width of the entire banner

    # INPUT VALIDATION
    # message
    validate_string(message, 'message')
    # delim_char
    validate_string(delim_char, 'delim_char')
    if len(delim_char) > 1:
        actual_delim = delim_char[0]
    else:
        actual_delim = delim_char
    # thickness
    validate_type(thickness, 'thickness', int)
    if thickness < 1:
        raise ValueError('Invalid "thickness" value')

    # PRINT THE BANNER
    banner_len = len(message) + 2 + (thickness * 2)  # Length of the frame
    # Top
    for _ in range(0, thickness):
        print(actual_delim * banner_len)
    # Middle
    print(f'{actual_delim * thickness} {message} {actual_delim * thickness}')
    # Bottom
    for _ in range(0, thickness):
        print(actual_delim * banner_len)
    # Trailing newline
    print('')


def print_exception(error: Exception) -> str:
    """Standardizes exception messages and prints to stderr.

    Determines error exception type and formats the message with message_template.

    Args:
        error: Exception (or a class inherited from it) object.

    Returns:
        A string containing the formatted exception message.

    Raises:
        TypeError: error is not an Exception (or inherited from) type.
    """
    # LOCAL VARIABLES
    exception_type = ''                # Human-readable Exception type (e.g., Value)
    message_template = '{} ERROR: {}'  # Template message format
    exception_str = ''                 # Human-readable exception message
    formatted_msg = ''                 # End result message to return

    # INPUT VALIDATION
    validate_type(error, 'error', Exception)

    # FORMAT
    if isinstance(error, FileNotFoundError):
        exception_type = 'FILE'
    elif isinstance(error, OSError):
        exception_type = 'OS'
    elif isinstance(error, RuntimeError):
        exception_type = 'RUNTIME'
    elif isinstance(error, TypeError):
        exception_type = 'TYPE'
    elif isinstance(error, ValueError):
        exception_type = 'VALUE'
    else:
        exception_type = 'GENERAL'

    # PRINT
    # Str wrapper is important in case error.args[0] contains an errno value
    if isinstance(error, FileNotFoundError):
        exception_str = str(error)
    else:
        exception_str = str(error.args[0])
    formatted_msg = message_template.format(exception_type, exception_str)
    print(formatted_msg, file=sys.stderr)

    # DONE
    return formatted_msg


def replace_chars(bad_chars: list, haystack: str, new_char: str = '_') -> str:
    """Replaces all occurrences of bad_chars with new_char in haystack.

    Replacements are case-sensitive. If new_char is an empty string, bad_chars will be removed from
    the haystack. If haystack is empty, the function returns an empty string.

    Args:
        bad_chars: A list of chars to look for in the haystack.
        haystack: The string that will be modified.
        new_char: Optional; The replacement for bad_chars.

    Returns:
        An empty string or a string containing a copy of haystack in which all occurrences of
            bad_chars have been replaced.

    Raises:
        TypeError: Invalid data type.
        ValueError: bad_chars is empty.
    """
    # LOCAL VARIABLES
    new_str = ''

    # INPUT VALIDATION
    validate_list(bad_chars, 'bad_chars', can_be_empty=False)
    for entry in bad_chars:
        validate_string(entry, 'bad_chars entry')
        if len(entry) > 1:
            raise ValueError('"bad_chars" contains a string that is too long')
    validate_string(haystack, 'haystack', can_be_empty=True)
    validate_string(new_char, 'new_char', can_be_empty=True)

    # REPLACE IT
    for old_char in haystack:
        if old_char in bad_chars:
            new_str = new_str + new_char
        else:
            new_str = new_str + old_char

    # DONE
    return new_str


def safe_call(func: types.FunctionType, args: tuple = (), kwargs: dict = None,
              file: io.IOBase = sys.stderr) -> bool:
    """Safely calls specified function with arguments provided.

    Wraps a function call in an except to catch, print, and report on the success or failure
        of that function call.

    Args:
        func: Function to call.
        args: Tuple containing the arguments to pass to func()
        kwargs: Dictionary containing the keyword arguments to pass to func()
        file: Optional; File object to print the exception details, if any

    Returns:
        True if func(*args, **kwargs) returned without Exception, otherwise false.

    Raises:
        TypeError: Invalid data type.
        ValueError: Invalid value or func is not callable.
    """
    # LOCAL VARIABLES
    success = True         # Holds the success of the function call to return
    local_kwargs = kwargs  # Local copy of kwargs to avoid pylint warning

    # INPUT VALIDATION
    # func
    validate_callable(func, 'func')
    # args
    validate_type(args, 'args', tuple)
    # local_kwargs
    if local_kwargs is None:
        local_kwargs = {}
    else:
        validate_type(local_kwargs, 'kwargs', dict)
    # file
    validate_type(file, 'file', io.IOBase)

    try:
        func(*args, **local_kwargs)
    except Exception as err:  # pylint: disable=broad-except
        print(f'{err.__class__.__name__}: {err}', file=file)
        success = False
    return success
