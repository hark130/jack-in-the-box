"""Holds common use functions for the *_automation.py modules.

This module contains functionality to execute systemctl commands.

    Typical usage example:

    from hobo.common_automation import (build_systemctl_cmd_list, get_systemctl_code
                                        execute_systemctl_cmd)

    build_systemctl_cmd_list(daemon_name, command, as_root)
    get_systemctl_code(daemon_name, command, as_root)
    execute_systemctl_cmd(daemon_name, 'reload', as_root=True)
"""

# Standard Imports
from typing import Tuple
# Third Party Imports
# Local Imports
# pylint: disable=import-error
from hobo.disk_operations import validate_directory
from hobo.makefile_rule_collection import MakefileRuleCollection
from hobo.subprocess_wrapper import execute_subprocess_cmd, get_subprocess_cmd_exit
from hobo.validation import validate_string, validate_type
# pylint: enable=import-error


def build_systemctl_cmd_list(daemon_name: str, command: str, as_root: bool) -> list:
    """Builds a list of commands necessary to execute a systemctl command.

    Builds list from given command and daemon_name. Validates command and as_root but not
    daemon_name.

    Args:
        daemon_name: The name of the systemd service to command.
        command: The systemctl command to issue.
        as_root: Optional; If True, executes the command with sudo.

    Returns:
        A list containing the commands necessary to execute a systemctl command.

    Raises:
        RuntimeError: An error ocurred during run-time.
        TypeError: Invalid data type.
        ValueError: Empty parameter.
    """
    # LOCAL VARIABLES
    systemctl_cmd_list = []  # systemctl command list to pass subprocess

    # INPUT VALIDATION
    # command
    validate_string(command, 'command')
    # as_root
    validate_type(as_root, 'as_root', bool)

    # EXECUTE
    # Build command list
    if as_root:
        systemctl_cmd_list = ['sudo'] + systemctl_cmd_list
    systemctl_cmd_list += ['systemctl', command, daemon_name]

    # DONE
    return systemctl_cmd_list


def get_systemctl_code(daemon_name: str, command: str, as_root: bool = True) -> int:
    """Executes `systemctl command daemon_name` and returns results.

    Calls get_subprocess_cmd_exit() under the hood. Parameter validation is handled by
    build_systemctl_cmd_list() but does not validate daemon_name. This function lets the caller
    decide the criteria for success or failure in the execution of the given systemctl command.

    From the man page for systemctl:
       ┌──────┬─────────────────────────────────────┐
       │Value │ Description in LSB                  │
       ├──────┼─────────────────────────────────────┤
       │0     │ "program is running or service is   │
       │      │ OK"                                 │
       ├──────┼─────────────────────────────────────┤
       │1     │ "program is dead and /var/run pid   │
       │      │ file exists"                        │
       ├──────┼─────────────────────────────────────┤
       │2     │ "program is dead and /var/lock lock │
       │      │ file exists"                        │
       ├──────┼─────────────────────────────────────┤
       │3     │ "program is not running"            │
       ├──────┼─────────────────────────────────────┤
       │4     │ "program or service status is       │
       │      │ unknown"                            │
       └──────┴─────────────────────────────────────┘

    Args:
        daemon_name: The name of the systemd service to command.
        command: The systemctl command to issue.
        as_root: Optional; If True, executes the command with sudo.

    Returns:
        An integer representing the command's exit code.

    Raises:
        RuntimeError: An error ocurred during run-time.
        TypeError: Invalid data type.
        ValueError: Empty parameter.
    """
    # LOCAL VARIABLES
    exit_code = 0            # Exit code from the systemctl command
    systemctl_cmd_list = []  # systemctl command list to pass subprocess

    # EXECUTE
    # Build command list
    systemctl_cmd_list = build_systemctl_cmd_list(daemon_name, command, as_root)
    # Execute command list
    exit_code = get_subprocess_cmd_exit(systemctl_cmd_list)

    # DONE
    return exit_code


def execute_systemctl_cmd(daemon_name: str, command: str, as_root: bool = True) -> Tuple[str, str]:
    """Executes `systemctl command daemon_name` and returns results.

    Calls execute_subprocess_cmd() under the hood. Parameter validation is handled by
    build_systemctl_cmd_list() but does not validate daemon_name. This function was written in an
    attempt to avoid duplicated code and lets the caller decide the criteria for success or failure
    in the execution of the given systemctl command.

    Args:
        daemon_name: The name of the systemd service to command.
        command: The systemctl command to issue.
        as_root: Optional; If True, executes the command with sudo.

    Returns:
        A tuple containing stdout and stderr from the systemctl command.

    Raises:
        TypeError: Invalid data type.
        ValueError: Empty parameter.
    """
    # LOCAL VARIABLES
    systemctl_cmd_list = []  # systemctl command list to pass subprocess

    # EXECUTE
    # Build command list
    systemctl_cmd_list = build_systemctl_cmd_list(daemon_name, command, as_root)
    # Execute command list
    return execute_subprocess_cmd(systemctl_cmd_list)


def _validate_parameters(repo_path: str, daemon_name: str,
                         rule_collection: MakefileRuleCollection, sleep_time: int) -> None:
    """Validates input on behalf of execute_*_on_daemon().

    Validates the type and content of all arguments provided.  Also, calls
    MakefileRuleCollection.verify().

    Args:
        repo_path: The relative or absolute pathname to the repo.
        daemon_name: The name of the systemd service to check.
        rule_collection: MakefileRuleCollection object containing the necessary MakefileRule
            objects necessary to clean, build, install, and uninstall the daemon_name.
        sleep_time: A non-negative number of seconds to pass to time.sleep.

    Raises:
        OSError: repo_path does not exist or repo_path is not a directory.
        TypeError: Invalid data type.
        ValueError: Empty parameter or sleep_time is negative.
        Bubbles up exceptions from MakefileRuleCollection.
    """
    # INPUT VALIDATION
    # repo_path
    validate_directory(repo_path, 'repo_path')
    # daemon_name
    validate_string(daemon_name, 'daemon_name')
    # rule_collection
    validate_type(rule_collection, 'rule_collection', MakefileRuleCollection)
    rule_collection.verify()
    # sleep_time
    validate_type(sleep_time, 'sleep_time', int)
    if sleep_time < 0:
        raise ValueError('sleep_time must be non-negative')
