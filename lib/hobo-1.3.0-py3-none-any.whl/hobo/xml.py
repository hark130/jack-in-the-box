"""Common operations on XML-formatted data.

This module contains functionality that parses and compares XML-formatted data.

    Typical usage example:

    from hobo.xml import (compare_raw_xml_strs, compare_xml_file_to_str, compare_xml_files,
                          has_content, has_xml_tag, remove_xml_tag)

    if not compare_raw_xml_strs('<a/>', '<a>\n\t</a>'):
        print('These XML strings do not match')

    if not compare_xml_file_to_str('my_file.xml', '<xml><label1>text1</label1></xml>'):
        print('File does not match string')

    if not compare_xml_files('my_file.xml', 'my_other_file.xml'):
        print('These two files do not match')

    if not has_xml_tag('./tag1/tag2', xml_string):
        print('This tag is missing')

    if has_content('./tag1/tag2', xml_string):
        print('This tag has content')

    new_xml_string = remove_xml_tag('./tag', original_xml_string)
"""

# Standard Imports
# Third Party Imports
from xml.etree import ElementTree
# Local Imports
from hobo.disk_operations import validate_file
from hobo.validation import validate_string, validate_type


def compare_raw_xml_strs(raw_xml1: str, raw_xml2: str) -> bool:
    """Compare two xml strings.

    Parses, canonicalizes, and compares the contents of xml-formatted strings.  The strings
    will be stripped prior to comparison: comments, non-text content whitespace, etc.
    Input validated by internal helper functions.

    Args:
        raw_xml1: A string contaning valid XML data to compare to raw_xml2.
        raw_xml2: A string contaning valid XML data to compare to raw_xml1.

    Raises:
        TypeError: Bad data type.
        ValueError: Empty string.
        SyntaxError: String isn't valid XML.

    Returns:
        True if the same, False otherwise.
    """
    return _compare_xml_strings(raw_xml1, raw_xml2, canonicalize=True)


def compare_xml_file_to_str(xml_filename: str, xml_str: str, parse_str: bool = False) -> bool:
    """Compare an XML file to an xml string.

    Parses, canonicalizes, and compares the contents of an xml-formatted file to a string.
    Input validated by internal helper functions.

    Args:
        xml_filename: Filename, relative or absolute, of an XML-formatted file to compare.
        xml_str: String to compare to the parsed contents of xml_file.
        parse_str: Optional; Canonicalize xml_str, the same way xml_filename gets parsed
            pre-comparison, if True.  Use this on raw XML to strip whitespace before and after
            text content.

    Raises:
        TypeError: Bad data type.
        ValueError: Empty xml_filename.
        FileNotFoundError: xml_filename was not found.
        OSError: xml_filename is not a file.
        SyntaxError: xml_filename or xml_str is not XML-formatted.

    Returns:
        True if the same, False otherwise.
    """
    # LOCAL VARIABLES
    xml_file_str = _parse_xml_file(xml_filename)  # XML from xml_filename

    # COMPARE
    return _compare_xml_strings(xml_file_str, xml_str, canonicalize=parse_str)


def compare_xml_files(file1: str, file2: str) -> bool:
    """Compare two XML files.

    Parses, canonicalizes, and compares the contents of two XML-formatted files.
    Input validated by internal helper functions.

    Args:
        file1: First filename, relative or absolute, to compare to file2.
        file2: Second filename, relative or absolute, to compare to file1.

    Raises:
        TypeError: Bad data type.
        ValueError: Empty filename.
        FileNotFoundError: A file was not found.
        OSError: One of the files is not a file.
        SyntaxError: One of the files is not XML-formatted.

    Returns:
        True if the same, False otherwise.
    """
    # LOCAL VARIABLES
    xml1 = _parse_xml_file(file1)  # XML from file1
    xml2 = _parse_xml_file(file2)  # XML from file2

    # COMPARE
    return _compare_xml_strings(xml1, xml2, canonicalize=False)


def has_content(xpath: str, xml_string: str) -> bool:
    """Denotes if an XML tag has content.

    Determines if an XML tag pair (e.g. <tag></tag>) has any non-whitespace characters.  This
    method will not indicate if the given tag contains tags; only if content exists
    within the specified tag.

    The variable xpath is an ElementTree supported XML Path Language (XPath) expression.
    ElementTree provides limited support for XPath.  An XPath is basically an address to an XML
    tag.  To indicate the XML root use an XPath that consists of a single '.' period.  If a
    tag below root is to be checked, add a single forward slash followed by the tag name. An
    example of this would be './tag' or './tag1/tag2/tag3'.

    Args:
        xpath: An XPath that denotes the address to a tag.
        xml_string: A string that contains XML to search through.

    Raises:
        TypeError: Bad data type.
        ValueError: Empty string.
        SyntaxError: Invalid XML String.
        SyntaxError: Invalid or unsupported XPath expression.
        SyntaxError: Unable to find xpath in xml_string.

    Returns:
        True if the xpath specified has any non-whitespace content, and False if otherwise.
    """
    # LOCAL VARIABLES
    content = False  # The XML tag content
    element = None   # An ElementTree Element instance

    # INPUT VALIDATION
    validate_string(xpath, 'xpath', can_be_empty=False)
    validate_string(xml_string, 'xml_string', can_be_empty=False)

    # FIND TAG CONTENT
    element = _get_element(xpath, xml_string)

    if element is None:
        raise SyntaxError(f'The {xpath} is not found in {xml_string}')
    if element.text is not None:
        if element.text.replace(' ', '').replace('\t', '').replace('\n', ''):
            content = True

    return content


def has_xml_tag(xpath: str, xml_string: str) -> bool:
    """Denotes the existence of an XML tag.

    Determines if the first occurrence of a given XML tag pair (e.g. <tag></tag>),
    indicated by an XPath expression, exists within the given XML string.

    The variable xpath is an ElementTree supported XML Path Language (XPath) expression.
    ElementTree provides limited support for XPath.  An XPath is basically an address to an XML
    tag.  To indicate the XML root use an XPath that consists of a single '.' period.  If a
    tag below root is to be checked, add a single forward slash followed by the tag name. An
    example of this would be './tag' or './tag1/tag2/tag3'.

    Args:
        xpath: An XPath expression that denotes the address to an XML tag.
        xml_string: A string that contains valid XML.

    Raises:
        TypeError: Bad data type.
        ValueError: Empty string.
        SyntaxError: Invalid XML String.
        SyntaxError: Invalid or unsupported XPath expression.

    Returns:
        True if tag exists, False otherwise.
    """
    # LOCAL VARIABLES
    found = False  # Indicates discovery of the XML tag

    # INPUT VALIDATION
    validate_string(xpath, 'xpath', can_be_empty=False)
    validate_string(xml_string, 'xml_string', can_be_empty=False)

    # FIND TAG
    if _get_element(xpath, xml_string) is not None:
        found = True

    return found


def remove_xml_tag(xpath: str, xml_string: str, ignore_missing: bool = False) -> str:
    """Removes an XML tag from a string containing XML and all XML comments.

    Removes an XML tag, all descendant tags, and any content contained therein.  The XPath
    expression (see: xpath argument) will attempt to match an XML tag in the XML string
    (see: xml_string argument).  If the XML tag is found it will be removed.

    WARNING: All comments are automatically removed by the underlying XML parser when a tag is
    removed.

    The variable xpath is an ElementTree supported XML Path Language (XPath) string.  ElementTree
    provides limited support for XPath.  An XPath is basically an address to an XML tag.
    To indicate the XML root use an XPath that consists of a single '.' period.  If a
    tag below root is to be checked, add a single forward slash followed by the tag name. An
    example of this would be './tag' or './tag1/tag2/tag3'.

    Args:
        xpath: An XPath that denotes the address to a tag.
        xml_string: A string that contains valid XML.
        ignore_missing: Optional; If True, ignores missing xpath expressions and returns xml_string
            in situations where xpath can not be found.

    Raises:
        TypeError: Bad data type.
        ValueError: Empty string.
        SyntaxError: Parse error with XML string.
        SyntaxError: Invalid or unsupported XPath expression.
        SyntaxError: Unanticipated XPath exception.
        SyntaxError: Invalid or unsupported XPath root expression.
        RuntimeError: Unable to find xpath in xml_string.
        RuntimeError: Unable to find xpath parent in xml_string, in the off chance that the tag to
            be removed is valid and the parent tag is invalid.

    Returns:
        If the XML tag is found, an XML string without the indicated tag or any comments.  If the
        tag is not found and ignore_missing is True, the original XML string will be returned. If
        the tag is not found and ignore_missing is False (default), then an exception is raised.
    """
    # LOCAL VARIABLES
    child = None             # Child node to delete
    normal = ''              # XML without whitespace
    parent = None            # Parent node
    processed = xml_string   # XML string to return
    root = None              # Root XML object

    # INPUT VALIDATION
    validate_type(ignore_missing, 'ignore_missing', bool)
    validate_string(xpath, 'xpath', can_be_empty=False)
    validate_string(xml_string, 'xml_string', can_be_empty=False)

    # REMOVE TAG
    try:
        normal = ElementTree.canonicalize(xml_string, strip_text=True)
        root = ElementTree.fromstring(normal)
        child = root.find(xpath)
    except ElementTree.ParseError as err:
        raise SyntaxError(err.msg) from err  # Convert error to a builtin
    except (KeyError, TypeError) as err:
        raise SyntaxError(f'Invalid or unsupported XPath expression: {xpath}') from err
    except Exception as err:
        raise SyntaxError(f'Invalid or unsupported XPath expression {xpath}. Received '
                          f'unanticipated exception of {str(err)}') from err

    if child is None and not ignore_missing:
        raise RuntimeError(f'Unable to find {xpath} in {xml_string}')
    if child is not None:
        try:
            parent = root.find(xpath + '/..')
        except KeyError as err:
            raise SyntaxError(f'Invalid or unsupported XPath root expression: {xpath}') from err

        if parent is None:
            raise RuntimeError(f'Unable to find {xpath} parent in {xml_string}')

        parent.remove(child)
        processed = ElementTree.tostring(root, short_empty_elements=False).decode('ascii')

    return processed


#############################
# INTERNAL HELPER FUNCTIONS #
#############################


def _compare_xml_strings(xml1: str, xml2: str, canonicalize: bool) -> bool:
    """Compare two XML strings.

    Compares the contents of two XML-formatted strings.

    Args:
        xml1: First string to compare.
        xml2: Second string to compare.
        canonicalize: Canonicalize both strings prior to comparison by stripping comments,
            whitespace before/after text content, etc.

    Raises:
        TypeError: Bad data type.
        ValueError: Empty string.
        SyntaxError: XML string not XML-formatted.
    """
    # LOCAL VARIABLES
    local_xml1 = xml1  # Local copy of xml1
    local_xml2 = xml2  # Local copy of xml2

    # INPUT VALIDATION
    validate_string(local_xml1, 'xml1', can_be_empty=False)
    validate_string(local_xml2, 'xml2', can_be_empty=False)
    validate_type(canonicalize, 'canonicalize', bool)

    # CANONICALIZE
    if canonicalize:
        try:
            local_xml1 = ElementTree.canonicalize(xml1, strip_text=True)
            local_xml2 = ElementTree.canonicalize(xml2, strip_text=True)
        except ElementTree.ParseError as err:
            raise SyntaxError(err.msg) from err  # Convert error to a builtin

    # COMPARE
    return local_xml1 == local_xml2


def _get_element(xpath: str, xml_string: str) -> ElementTree.Element:
    """Gets the Element instance of an XPath in an XML string.

    Finds the first occurrence of xpath in xml_string.  This method does not validate input.

    The variable xpath is an ElementTree supported XML Path Language (XPath) string.  ElementTree
    provides limited support for XPath.  An XPath is basically an address to an XML tag.
    To indicate the XML root use an XPath that consists of a single '.' period.  If a
    tag below root is to be checked, add a single forward slash followed by the tag name. An
    example of this would be './tag' or './tag1/tag2/tag3'.

    The variable xml_string is a string that contains valid XML.

    Args:
        xpath: An XPath that denotes the address to a tag.
        xml_string: A string that contains XML to search through.

    Raises:
        TypeError: Bad data type.
        SyntaxError: Invalid XML String.
        SyntaxError: Invalid XPath.

    Returns:
        An Element instance if found, or None if not.
    """
    # LOCAL VARIABLES
    root = None     # Root Element
    element = None  # An ElementTree Element instance

    # FIND ELEMENT
    try:
        root = ElementTree.fromstring(xml_string)
    except ElementTree.ParseError as err:
        raise SyntaxError(f'Invalid XML String {xml_string}: {str(err)}') from err

    try:
        element = root.find(xpath)
    except Exception as err:
        raise SyntaxError(f'Invalid XPath {xpath}: {err}') from err

    return element


def _parse_xml_file(filename: str, strip_text: bool = True) -> str:
    """Parse an XML file to a string.

    Parse filename as an XML formatted file and convert the XML to a string, stripping whitespace.

    Args:
        filename: A relative or absolute filename to an XML-formatted file.
        strip_text: Optional; Strip whitespace before and after text content.

    Returns:
        A string, stripped of whitespace before and after text content, containing the XML data.

    Raises:
        TypeError: Filename is not a string.
        ValueError: Filename is empty.
        FileNotFoundError: Filename is not found.
        OSError: Filename is not a file.
        SyntaxError: Filename was not XML-formatted.
    """
    # LOCAL VARIABLES
    xml_str = ''  # Parsed XML from filename

    # INPUT VALIDATION
    validate_file(filename, 'filename', must_exist=True)
    validate_type(strip_text, 'strip_text', bool)

    # PARSE IT
    try:
        xml_str = ElementTree.canonicalize(from_file=filename, strip_text=strip_text)
    except ElementTree.ParseError as err:
        raise SyntaxError(err.msg) from err  # Convert error to a builtin

    # DONE
    return xml_str
