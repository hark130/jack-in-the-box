"""Defines the ValgrindLogParser class.

Defines the ValgrindLogParser class to parse and analyze Valgrind log files.

    Typical usage example:

    log_parser = ValgrindLogParser(valgrind_log_file)
    log_parser.parse()
    if log_parser.check_for_errors():
        print(log_parser.get_report())
    else:
        print('Valgrind approves')
"""

# Standard Imports
from collections import OrderedDict
from typing import Any
import re
# Third Party Imports
# Local Imports
# pylint: disable=import-error
from hobo.disk_operations import validate_file
from hobo.misc import extricate_numbers
from hobo.validation import validate_list, validate_string, validate_type
# pylint: enable=import-error


def validate_internal_list(validate_this: list, param_name: str,
                           can_be_empty: bool = True) -> None:
    """Wrap validate_list() with standard 'internal' verbiage.

    Wraps param_name with mention of being an 'internal attribute'.  Other arguments are a
    pass-through.

    Args:
        validate_this: The parameter to validate
        param_name: The name of the parameter (used in exception messages)
        can_be_empty: Optional; If False, this function will verify that validate_this is
            *not* empty.

    Raises:
        TypeError: "validate_this" is not a list
        ValueError: "validate_this" is empty and can_be_empty is False
    """
    validation_verbiage = 'Internal attribute "{}"'  # Standard validation verbiage wrapper
    validate_list(validate_this=validate_this, param_name=validation_verbiage.format(param_name),
                  can_be_empty=can_be_empty)


def validate_internal_string(validate_this: str, param_name: str,
                             can_be_empty: bool = False) -> None:
    """Wrap validate_string() with standard 'internal' verbiage.

    Wraps param_name with mention of being an 'internal attribute'.  Other arguments are a
    pass-through.

    Args:
        validate_this: The parameter to validate
        param_name: The name of the parameter (used in exception messages)
        can_be_empty: Optional; If False, this function will verify that validate_this is
            *not* empty.

    Raises:
        TypeError: "validate_this" is not a string
        ValueError: "validate_this" is empty and can_be_empty is False
    """
    validation_verbiage = 'Internal attribute "{}"'  # Standard validation verbiage wrapper
    validate_string(validate_this=validate_this, param_name=validation_verbiage.format(param_name),
                    can_be_empty=can_be_empty)


def validate_internal_type(var: Any, var_name: str, var_type: type) -> None:
    """Wrap validate_type() with standard 'internal' verbiage.

    Wraps var_name with mention of being an 'internal attribute'.  Other arguments are a
    pass-through.

    Args:
        var: Variable to validate type
        var_name: Variable name
        var_type: Expected variable type

    Raises:
        TypeError: The type of var doesn't match var_type
    """
    validation_verbiage = 'Internal attribute "{}"'  # Standard validation verbiage wrapper
    validate_type(var=var, var_name=validation_verbiage.format(var_name), var_type=var_type)


# pylint: disable=too-many-instance-attributes
class ValgrindLogParser:
    """Reads, parses, interprets, and prettifies Valgrind log files.

    Usage:
        1. parsed_log = ValgrindLogParser(my_log)
        2. parsed_log.parse()  # Validates, reads, and parses the log
        3. parsed_log.check_for_errors()  # If True, print get_report()

    Notes:
        Known BUG: _populate_summaries_misc() doesn't verify the unique nature
            of bad string list entries it is counting.  Sometimes, for
            whatever reason, Valgrind duplicates entries.  The identifying
            feature of a duplicate entry would be it's call chain.  TD: DDN.
        Known FEEDBACK: Given more time, many of these internally stored
            tuples would be better served stored as class-defined NamedTuples
        Possible BUG: _parse_heap_summary_list() may contain a BUG specific
            to realloc.  If Valgrind counts multiple calls to realloc() as
            different "alloc" counts but only counts the call to free() once
            then `allocs != frees` might be a valid use case.  If so, this
            method contains a BUG because it compares the alloc count to the
            free count during error checking.  TD: DDN.

    Attributes:
        None
    """

    _commentary_header = re.compile(r'^--\d+-- ')  # Matches "--PID-- "
    _error_header = re.compile(r'^==\d+== ')       # Matches "==PID== "
    _pid = re.compile(r'\d+')                      # Matches "1" through "∞"
    # List of bad strings to look for in the Valgrind log
    _bad_string_list = [
        # Indicates uninitialised variables/memory is in use
        'uninitialised value',
        # Reading from memory that doesn't belong to you
        'invalid read',
        # Writing to memory that doesn't belong to you
        'invalid write',
        # Invalid free() / delete / delete[] / realloc()
        'invalid free',
        # Argument 'size'...has a fishy (possibly negative) value: -1
        'fishy',
        # 65 bytes in 1 blocks are definitely lost in loss record 1 of 1
        'definitely lost in',
    ]
    _parsed_dict = {
        'HIGHLIGHTS': {
            # self._log
            'log_filename': '',
            # Parsed 'Command:' string from the log
            'command': '',
            # Parsed PIDs, as strings, from the log
            'PIDs': [],
            # Any self._bad_string_list hits, stored as strings, from the log
            'list_of_bad_strings': [],
        },
        'SUMMARIES': {
            'Misc': {
                # count
                'invalid_read': 0,
                # count
                'invalid_write': 0,
                # count
                'invalid_free': 0,
                # count
                'fishy_values': 0,
                # count
                'uninit_values': 0,
                # count
                'definite_leaks': 0,
            },
            'Heap': {
                # bytes, blocks
                'at_exit': tuple((0, 0)),
                # allocs, frees, bytes allocated
                'total_usage': tuple((0, 0, 0)),
            },
            'Error': {
                'num_errors': tuple((0, 0)),
                'suppressed': tuple((0, 0)),
            },
            'Leak': {
                # bytes, blocks
                'definitely_lost': tuple((0, 0)),
                # bytes, blocks
                'indirectly_lost': tuple((0, 0)),
                # bytes, blocks
                'possibly_lost': tuple((0, 0)),
                # bytes, blocks
                'still_reachable': tuple((0, 0)),
                # bytes, blocks
                'suppressed': tuple((0, 0)),
            },
        },
    }
    # Lookup table for Valgrind verbiage to _parsed_dict dict 'Heap' key
    _lookup_heap = OrderedDict([
        ('in use at exit', 'at_exit'),
        ('total heap usage', 'total_usage'),
    ])
    # Lookup table for Valgrind verbiage to _parsed_dict dict 'Leak' key
    _lookup_leak = OrderedDict([
        ('definitely lost', 'definitely_lost'),
        ('indirectly lost', 'indirectly_lost'),
        ('possibly lost', 'possibly_lost'),
        ('still reachable', 'still_reachable'),
        ('suppressed', 'suppressed'),
    ])

    def __init__(self, log_filename: str) -> None:
        """Class ctor.

        Need to call the 'parse' method first to obtain the contents of log_filename.

        Args:
            log_filename: The absolute or relative Valgrind log filename.

        Raises:
            None
        """
        self._log = log_filename
        self._parsed = False            # Status of the log, parsed or not
        self._raw_log_contents = ''     # Original log contents
        self._parsed_log_contents = []  # List of stripped log content strings
        self._highlight_report = ''     # Formatted HIGHLIGHTS report
        self._summary_report = ''       # Formatted SUMMARY report
        self._summary_misc_report = ''  # Formatted SUMMARY Misc report
        self._summary_heap_report = ''  # Formatted SUMMARY Heap report
        self._summary_errs_report = ''  # Formatted SUMMARY Errors report
        self._summary_leak_report = ''  # Formatted SUMMARY Leak report
        self._full_report = ''          # Full and formatted report
        self._found_error = False       # Indicates if Valgrind found an error

    def parse(self) -> None:
        """Parse log_filename.

        Validate, read, and parse the log_filename.

        Raises:
            TypeError: The type of log_filename, or any internal attribute, is invalid.
            ValueError: log_filename, or other applicable values, contain invalid data.
            FileNotFoundError: log_filename is not found.
            OSError: log_filename is not a file.
        """
        # INPUT VALIDATION
        self._validate_attributes()

        # READ LOG FILE
        with open(self._log, 'r', encoding='utf-8') as in_log_file:
            self._raw_log_contents = in_log_file.read()

        # PARSE RAW CONTENTS
        self._strip_log_contents()
        self._populate_highlights()
        self._populate_summaries()

        # DONE
        self._parsed = True

    def get_report(self) -> str:
        """Formats and returns the report.

        Formats and returns the report that contains the highlights and summaries.

        Returns:
            A string containing the report.

        Raises:
            RuntimeError: This method is called before the parse() method.
        """
        # INPUT VALIDATION
        self._verify_parsed()

        # PREPARE REPORTS
        # Highlight
        self._create_report_highlights()
        # Summary
        self._create_report_summaries()
        # Full
        self._full_report = f'{self._highlight_report}\n{self._summary_report}'

        # DONE
        return self._full_report

    def check_for_errors(self) -> bool:
        """Checks for errors.

        Notifies the user if any error was found.

        Returns:
            True if an error was found, False otherwise.

        Raises:
            RuntimeError: This method is called before the parse() method.
        """
        # INPUT VALIDATION
        self._verify_parsed()

        # DONE
        return self._found_error

    def _create_report_highlights(self) -> None:
        """Creates the HIGHLIGHTS report.

        Concatenates all necessary information to create the HIGHLIGHTS report.

        Raises:
            None
        """
        # LOCAL VARIABLES
        sub_dict = self._get_highlights_dict()  # Sub dictionary
        # Format and concatenated report contents
        temp_report = 'HIGHLIGHTS'

        # CONCATENATE
        if self._log:
            temp_report = temp_report + f'\n\tLog Filename: {self._log}'
        if sub_dict['command']:
            temp_report = temp_report + f"\n\tCommand: {sub_dict['command']}"
        if sub_dict['list_of_bad_strings']:
            temp_report = temp_report \
                + '\n\tSeek out the log sections that contains these strings:'
            for bad_entry in sub_dict['list_of_bad_strings']:
                if bad_entry not in temp_report:
                    temp_report = temp_report + f'\n\t\t{bad_entry}'

        # DONE
        self._highlight_report = temp_report + '\n'

    def _create_report_summaries(self) -> None:
        """Concatenates all the Summary reports.

        Calls methods to create *all* Summary reports and concatenates them.

        Raises:
            None
        """
        # LOCAL VARIABLES
        temp_report = 'SUMMARIES'  # Concatenation of the full summary report

        # CREATE
        self._create_report_summaries_misc()
        self._create_report_summaries_heap()
        self._create_report_summaries_errors()
        self._create_report_summaries_leak()

        # CONCATENATE
        if self._summary_errs_report:
            temp_report = temp_report + '\n' + self._summary_errs_report
        if self._summary_heap_report:
            temp_report = temp_report + '\n' + self._summary_heap_report
        if self._summary_leak_report:
            temp_report = temp_report + '\n' + self._summary_leak_report
        if self._summary_misc_report:
            temp_report = temp_report + '\n' + self._summary_misc_report

        # DONE
        self._summary_report = temp_report + '\n'

    def _create_report_summaries_misc(self) -> None:
        """Creates the SUMMARIES MISC report.

        Concatenates all necessary information to create the SUMMARIES MISC reports.

        Raises:
            None
        """
        # LOCAL VARIABLES
        # Top-level dictionary storing the key/value pair
        sub_dict = self._get_summaries_dict()['Misc']
        temp_report = '\tMISC:'  # Concatenation of the misc summary report

        # CONCATENATE
        temp_report = temp_report + '\n\t\tuninitialised values: ' + \
            f"{sub_dict['uninit_values']}"
        temp_report = temp_report + '\n\t\tinvalid reads: ' + \
            f"{sub_dict['invalid_read']}"
        temp_report = temp_report + '\n\t\tinvalid writes: ' + \
            f"{sub_dict['invalid_write']}"
        temp_report = temp_report + '\n\t\tinvalid frees: ' + \
            f"{sub_dict['invalid_free']}"
        temp_report = temp_report + '\n\t\tfishy values: ' + \
            f"{sub_dict['fishy_values']}"
        temp_report = temp_report + '\n\t\tdefinite memory leaks: ' + \
            f"{sub_dict['definite_leaks']}"

        # DONE
        self._summary_misc_report = temp_report

    def _create_report_summaries_heap(self) -> None:
        """Creates the SUMMARIES HEAP report.

        Concatenates all necessary information to create the SUMMARIES HEAP report.

        Raises:
            RuntimeError: Unable to find internal sub-dicts.
            TypeError: Internal attributes are the wrong type.
            ValueError: Internal attributes contain bad values.
        """
        # LOCAL VARIABLES
        # Top-level dictionary storing the key/value pair
        sub_dict = self._get_summaries_dict()['Heap']
        num_at_exit = tuple((0, 0))    # Number of bytes and blocks at exit
        num_totals = tuple((0, 0, 0))  # Number of allocs, frees, and bytes
        temp_report = '\tHEAP:'        # Build the HEAP summary here

        # INTERNAL VALIDATION
        # Fetch
        try:
            num_at_exit = sub_dict['at_exit']
            num_totals = sub_dict['total_usage']
        except KeyError as exc:
            raise RuntimeError('Encountered internal error with missing '
                               'summarized heap') from exc
        # num_at_exit
        validate_internal_type(num_at_exit, 'num_at_exit', tuple)
        if len(num_at_exit) != 2:
            raise ValueError('Internal attribute "num_at_exit" is of '
                             f'length {len(num_at_exit)} instead of 2')
        for value in num_at_exit:
            validate_internal_type(value, 'num_at_exit entry', int)
        # num_totals
        validate_internal_type(num_totals, 'num_totals', tuple)
        if len(num_totals) != 3:
            raise ValueError('Internal attribute "num_totals" is of '
                             f'length {len(num_totals)} instead of 3')
        for value in num_totals:
            validate_internal_type(value, 'num_totals entry', int)

        # CONCATENATE
        temp_report = temp_report + f'\n\t\tAt exit: {num_at_exit[0]} ' + \
            f'bytes in {num_at_exit[1]} blocks in use'
        temp_report = temp_report + '\n\t\tTotal usage:' + \
            f'\n\t\t\tNum allocs: {num_totals[0]}' + \
            f'\n\t\t\tNum frees: {num_totals[1]}' + \
            f'\n\t\t\tBytes allocated: {num_totals[2]}'

        # DONE
        self._summary_heap_report = temp_report

    def _create_report_summaries_errors(self) -> None:
        """Creates the SUMMARIES ERRORS report.

        Concatenates all necessary information to create the SUMMARIES ERRORS report.

        Raises:
            RuntimeError: Unable to find internal sub-dicts.
            TypeError: Internal attributes are the wrong type.
            ValueError: Internal attributes contain bad values.
        """
        # LOCAL VARIABLES
        # Top-level dictionary storing the key/value pair
        sub_dict = self._get_summaries_dict()['Error']
        num_errors = tuple((0, 0))      # Number of errors from dictionary
        num_suppressed = tuple((0, 0))  # Supression numbers from dictionary

        # INTERNAL VALIDATION
        # Fetch
        try:
            num_errors = sub_dict['num_errors']
            num_suppressed = sub_dict['suppressed']
        except KeyError as exc:
            raise RuntimeError('Encountered internal error with missing '
                               'summarized errors') from exc
        # num_errors
        validate_type(num_errors, 'num_errors', tuple)
        if len(num_errors) != 2:
            raise ValueError('Internal attribute "num_errors" is of '
                             f'length {len(num_errors)} instead of 2')
        for value in num_errors:
            validate_internal_type(value, 'num_errors entry', int)
        # num_suppressed
        validate_type(num_suppressed, 'num_suppressed', tuple)
        if len(num_suppressed) != 2:
            raise ValueError('Internal attribute "num_suppressed" is of '
                             f'length {len(num_suppressed)} instead of 2')
        for value in num_suppressed:
            validate_internal_type(value, 'num_suppressed entry', int)

        # CONCATENATE
        self._summary_errs_report = '\tERRORS: Encountered a total of ' + \
                                    f'{num_errors[0]} errors ' + \
                                    f'from {num_errors[1]} contexts ' + \
                                    f'(suppressed {num_suppressed[0]} ' + \
                                    f'from {num_suppressed[1]})'

    def _create_report_summaries_leak(self) -> None:
        """Creates the SUMMARIES LEAK report.

        Concatenates all necessary information to create the SUMMARIES LEAK report.

        Raises:
            RuntimeError: Internal attribute is malformed or missing.
        """
        # LOCAL VARIABLES
        # Top-level dictionary storing the key/value pair
        sub_dict = self._get_summaries_dict()['Leak']
        temp_report = '\tLEAKS:'    # Build the LEAK summary here

        # CREATE
        try:
            for key, value in self._lookup_leak.items():
                temp_report = temp_report + f'\n\t\t{key}: ' + \
                              f'{sub_dict[value][0]} bytes in ' + \
                              f'{sub_dict[value][1]} blocks'
        except IndexError as exc:
            raise RuntimeError('Encountered internal error with a malformed '
                               'tuple inside summarized leak values') from exc
        except KeyError as exc:
            raise RuntimeError('Encountered internal error with missing '
                               'summarized leaks entry') from exc

        # DONE
        self._summary_leak_report = temp_report

    def _get_highlights_dict(self) -> dict:
        """Returns the "HIGHLIGHTS" top-level dictionary from self._parsed_dict."""
        return self._parsed_dict['HIGHLIGHTS']

    def _get_summaries_dict(self) -> dict:
        """Returns the "SUMMARIES" top-level dictionary from self._parsed_dict."""
        return self._parsed_dict['SUMMARIES']

    def _parse_heap_summary_list(self, log_list: list) -> None:
        """Parses a list for HEAP SUMMARY entries.

        Stops looking when internal functionality raises an Exception or an empty string is
        encountered (signalling the end of the HEAP SUMMARY section). If log_list is empty,
        it is ignored.

        Args:
            log_list: A list of strings to parse for heap information.

        Raises:
            TypeError: log_list is not a list or a non-string is encountered in the list.
        """
        # LOCAL VARIABLES
        # Top-level dictionary that holds the key/value pairs
        sub_dict = self._get_summaries_dict()['Heap']

        # INPUT VALIDATION
        validate_internal_list(log_list, 'log_list', can_be_empty=True)

        # PARSE (AND VALIDATE)
        for entry in log_list:
            validate_internal_string(entry, 'log_list entry', can_be_empty=True)
            if not entry:
                break  # Empty string.  End of section.
            try:
                self._populate_summaries_heap_attribute(entry)
            except RuntimeError:
                break  # No matching LEAK SUMMARY entries.  Must be done.

        # ANALYZE RESULTS
        # At exit
        if sub_dict['at_exit'][0] > 0:
            self._found_error = True  # Any bytes left at exit is an error
        # Allocs vs frees
        # NOTE: Is this statement a BUG for realloc?
        elif sub_dict['total_usage'][0] != sub_dict['total_usage'][1]:
            self._found_error = True  # Allocs aren't equal to frees

    def _parse_leak_summary_list(self, log_list: list) -> None:
        """Parses a list for LEAK SUMMARY entries.

        Stops looking when internal functionality raises an Exception or an empty string is
        encountered (signalling the end of the LEAK SUMMARY section). If log_list is empty,
        it is ignored.

        Args:
            log_list: A list of strings to parse for leak information.

        Raises:
            TypeError: log_list is not a list or a non-string is encountered in the list.
        """
        # INPUT VALIDATION
        validate_internal_list(log_list, 'log_list', can_be_empty=True)

        # PARSE (AND VALIDATE)
        for entry in log_list:
            validate_internal_string(entry, 'log_list entry', can_be_empty=True)
            if not entry:
                break  # Empty string.  End of section.
            try:
                self._populate_summaries_leak_attribute(entry)
            except RuntimeError:
                break  # No matching LEAK SUMMARY entries.  Must be done.

    def _populate_highlights(self) -> None:
        """Populates the HIGHLIGHTS key.

        Populates the HIGHLIGHTS key of the parsed dictionary from self._parsed_log_contents.
        """
        # LOCAL VARIABLES
        # Top-level dictionary storing the key/value pair
        sub_dict = self._get_highlights_dict()

        # POPULATE
        sub_dict['log_filename'] = self._log
        # Parsed 'Command:' string from the log
        self._populate_highlights_command()
        # PIDs was already populated by self._strip_log_contents()
        # Bad strings
        self._populate_highlights_bad_strings()

    def _populate_highlights_bad_strings(self) -> None:
        """Finds and stores bad strings.

        Parses the log contents to find and store bad strings.
        """
        # LOCAL VARIABLES
        # Top-level dictionary storing the key/value pair
        sub_dict = self._get_highlights_dict()

        # POPULATE
        for entry in self._parsed_log_contents:
            for bad_string in self._bad_string_list:
                if bad_string.lower() in entry.lower():
                    sub_dict['list_of_bad_strings'].append(entry)
                    break

    def _populate_highlights_command(self) -> None:
        """Finds and stores command.

        Parses the log contents to find and store the command.
        """
        # LOCAL VARIABLES
        needle = 'Command: '  # Message header for the command used
        # Top-level dictionary to store the key/value pair
        sub_dict = self._get_highlights_dict()

        # POPULATE
        for entry in self._parsed_log_contents:
            if entry.startswith('Command: '):
                sub_dict['command'] = entry[len(needle):]
                break

    def _populate_summaries(self) -> None:
        """Populates the SUMMARIES key.

        Populates the SUMMARIES key of the parsed dictionary from self._parsed_log_contents.
        """
        self._populate_summaries_misc()
        self._populate_summaries_heap()
        self._populate_summaries_errors()
        self._populate_summaries_leak()

    def _populate_summaries_errors(self) -> None:
        """Populates the SUMMARIES:Error key.

        Populates the SUMMARIES:Error key of the parsed dictionary from self._parsed_log_contents.
        If any errors were found, self._found_error is set to True.

        Raises:
            RuntimeError: Invalid count of number entries is found.
        """
        # LOCAL VARAIBLES
        # ERROR SUMMARY: 1 errors from 1 contexts (suppressed: 0 from 0)
        needle = 'ERROR SUMMARY:'  # Find this substring
        number_list = []           # Extracted numbers as ints
        num_errors = 0             # ERROR SUMMARY number of errors
        num_context = 0            # ERROR SUMMARY number of contexts
        num_suppressed = 0         # ERROR SUMMARY number suppressed
        num_from = 0               # ERROR SUMMARY number suppressed from
        # Top-level dictionary that holds the key/value pairs
        sub_dict = self._get_summaries_dict()['Error']

        # POPULATE
        for entry in self._parsed_log_contents:
            if entry.startswith(needle):
                # Extricate numbers
                number_list = extricate_numbers(entry)
                # Validate results
                if len(number_list) != 4:
                    raise RuntimeError('Encountered unexpected error while '
                                       f'parsing "{entry}"')
                # Add it up
                num_errors += number_list[0]
                num_context += number_list[1]
                num_suppressed += number_list[2]
                num_from += number_list[3]
            # Reset temp variables
            number_list = []

        # SAVE RESULTS
        sub_dict['num_errors'] = tuple((num_errors, num_context))
        sub_dict['suppressed'] = tuple((num_suppressed, num_from))

        # ANALYZE
        if num_errors > 0:
            self._found_error = True  # Valgrind reported at least one error

    def _populate_summaries_heap(self) -> None:
        """Finds and stores heap errors.

        Parses the log contents to find and store heap errors.
        """
        # LOCAL VARIABLES
        # Local copy of the contents.  Multiple HEAP sections may exist.
        sub_list = self._parsed_log_contents
        needle = 'HEAP SUMMARY:'  # Beginning of the heap summary section
        heap_summary_list = []    # Sub-list of heap summary entries

        # EXTRICATE HEAP SUMMARY LIST
        for entry in sub_list:
            # Found one
            if entry.startswith(needle):
                # Get the beginning of the HEAP SUMMARY entry list
                heap_summary_list = \
                    sub_list[self._parsed_log_contents.index(entry) + 1:]
                # Parse HEAP SUMMARY section
                self._parse_heap_summary_list(heap_summary_list)

    def _populate_summaries_heap_attribute(self, heap_str: str) -> None:
        """Parses and adds "HEAP SUMMARY" entries.

        Parses the heap_str based on predetermined substrings. The substring determines which
        dictionary entry gets the value. Values are added in to existing values because there may
        be multiple Heap Summary entries. Also, this function does not validate its parameters.

        Args:
            heap_str: A non-empty string to parse and assign.

        Raises:
            RuntimeError: Internal tuple is an invalid length.
        """
        # LOCAL VARIABLES
        # Top-level dictionary to store the key/value pair
        sub_dict = self._get_summaries_dict()['Heap']
        # Mapping of needles to dictionary keys
        str_to_key_lookup = self._lookup_heap
        number_list = []           # Numbers extricated from heap_str
        old_value = tuple()        # Variable length existing dict values
        new_value = []             # Variable length new dict values

        # SWITCH
        for key, value in str_to_key_lookup.items():
            if key in heap_str:
                # Get the numbers
                number_list = extricate_numbers(heap_str)
                # Get the old value
                old_value = sub_dict[value]
                # Validate results
                if len(old_value) != len(number_list):
                    raise RuntimeError('Encountered unexpected error while '
                                       f'parsing heap summary "{heap_str}"')
                # Store results
                for item in enumerate(number_list):
                    new_value.append(item[1] + old_value[item[0]])
                sub_dict[value] = tuple(new_value)

    def _populate_summaries_leak(self) -> None:
        """Finds and stores memory leaks.

        Parses the log contents to find and store memory leaks.
        """
        # LOCAL VARIABLES
        # Local copy of the contents.  Multiple LEAK sections may exist.
        sub_list = self._parsed_log_contents
        needle = 'LEAK SUMMARY:'  # Beginning of the leak summary section
        leak_summary_list = []    # Sub-list of leak summary entries

        # EXTRICATE LEAK SUMMARY LIST
        for entry in sub_list:
            # Found one
            if entry.startswith(needle):
                # Get the beginning of the LEAK SUMMARY entry list
                leak_summary_list = \
                    sub_list[self._parsed_log_contents.index(entry) + 1:]
                # Parse LEAK SUMMARY section
                self._parse_leak_summary_list(leak_summary_list)

    def _populate_summaries_leak_attribute(self, leak_str: str) -> None:
        """Parses and adds "LEAK SUMMARY" entries.

        Parses the leak_str based on predetermined substrings. The substring determines which
        dictionary entry gets the value. Values are added in to existing values because there may
        be multiple Leak Summary entries. Also, this function does not validate its parameters.

        Args:
            leak_str: A non-empty string to parse and assign.

        Raises:
            RuntimeError: This function parses an unexpected quantity of numbers.
        """
        # LOCAL VARIABLES
        # Top-level dictionary to store the key/value pair
        sub_dict = self._get_summaries_dict()['Leak']
        # Mapping of needles to dictionary keys
        str_to_key_lookup = self._lookup_leak
        number_list = []           # Numbers extricated from leak_str
        old_value = tuple((0, 0))  # Existing dictionary value

        # SWITCH
        for key, value in str_to_key_lookup.items():
            if key in leak_str:
                # Get the numbers
                number_list = extricate_numbers(leak_str)
                # Validate results
                if len(number_list) != 2:
                    raise RuntimeError('Encountered unexpected error while '
                                       f'parsing leak summary "{leak_str}"')
                # Analyze results
                if number_list[0] > 0:
                    self._found_error = True  # Any bytes lost is an error
                # Store results
                old_value = sub_dict[value]
                sub_dict[value] = tuple((number_list[0] + old_value[0],
                                         number_list[1] + old_value[1]))

    def _populate_summaries_misc(self) -> None:
        """Finds and stores misc violations.

        Parses the log contents to find and store misc violations.

        Raises:
            RuntimeError: "guard" protecting a brittle internal connection.
        """
        # LOCAL VARIABLES
        # Top-level dictionary to store the key/value pair
        sub_dict = self._get_summaries_dict()['Misc']
        # Top-level dictionary key list
        sub_dict_keys = sub_dict.keys()
        # Mapping of needles to dictionary keys
        str_to_key_lookup = {
            'uninitialised value': 'uninit_values',
            'invalid read': 'invalid_read',
            'invalid write': 'invalid_write',
            'invalid free': 'invalid_free',
            'fishy': 'fishy_values',
            'definitely lost in': 'definite_leaks',
        }

        # CLASS VALIDATION
        for value in str_to_key_lookup.values():
            if value not in sub_dict_keys:
                raise RuntimeError('The fragile connection between '
                                   '_populate_summaries_misc() and '
                                   '_parsed_dict has been broken')

        for entry in self._parsed_log_contents:
            for key, value in str_to_key_lookup.items():
                if key.lower() in entry.lower():
                    sub_dict[value] += 1
                    self._found_error = True  # Any of these is an error

    def _strip_log_contents(self) -> None:
        """Cleans up the raw log contents.

        Reads and stores PIDs, removes all line headers (e.g., ==PID==), and splits the raw string
        into a list attribute.

        Raises:
            TypeError: Log contents were read as a non-string.
            ValueError: Log contents were empty.
        """
        # LOCAL VARIABLES
        temp_header = ''              # ==PID== or --PID--
        temp_msg = ''                 # Everything after the header
        temp_pid = ''                 # PID stripped from the temp_header
        temp_match = None             # Return value from re.compile().search()
        temp_indices = tuple((0, 0))  # Start/stop indices from span()
        # Top-level HIGHLIGHTS dictionary from self._parsed_dict
        highlights_dict = self._get_highlights_dict()

        # INPUT VALIDATION
        validate_string(self._raw_log_contents, 'Raw log contents', can_be_empty=False)

        # STRIP LOG CONTENTS
        for log_entry in self._raw_log_contents.split('\n'):
            # 1. Clear temp variables
            temp_header = ''
            temp_msg = ''
            temp_pid = ''
            temp_match = None

            # 2. Get the header
            # Commentary
            temp_match = self._commentary_header.search(log_entry)
            if temp_match:
                temp_indices = temp_match.span()
                temp_header = log_entry[temp_indices[0]:temp_indices[1]]
                temp_msg = log_entry[temp_indices[1]:]
            # Error
            else:
                temp_match = self._error_header.search(log_entry)
                if temp_match:
                    temp_indices = temp_match.span()
                    temp_header = log_entry[temp_indices[0]:temp_indices[1]]
                    temp_msg = log_entry[temp_indices[1]:]

            # Determine PID in use
            if temp_header:
                temp_match = self._pid.search(temp_header)
                if temp_match:
                    temp_indices = temp_match.span()
                    temp_pid = temp_header[temp_indices[0]:temp_indices[1]]

            # Handle findings
            # NOTE: Even blank lines must be stored.  Blank lines are used
            # to denote section endings.
            self._parsed_log_contents.append(temp_msg)
            if temp_pid:
                if temp_pid not in highlights_dict['PIDs']:
                    highlights_dict['PIDs'].append(temp_pid)

    def _validate_attributes(self) -> None:
        """Validate class attributes.

        Validate the value that was passed in to the ctor.

        Raises:
            TypeError: log_filename isn't a string.
            ValueError: log_filename is empty.
            FileNotFoundError: log_filename is not found.
            OSError: log_filename is not a file.
        """
        # self._log
        validate_file(self._log, 'log_filename', must_exist=True)

    def _verify_parsed(self) -> None:
        """Verifies the log has been parsed.

        Checks if the parse() method has already been called.

        Raises:
            RuntimeError: The log hasn't been parsed yet.
        """
        if not self._parsed:
            raise RuntimeError('ERROR: Call the parse() method first!')
# pylint: enable=too-many-instance-attributes
