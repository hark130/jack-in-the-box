"""Subprocess-based functionality.

This modules contains subprocess wrapper functions.

    Typical usage example:

    from hobo.subprocess_wrapper import (execute_subprocess_cmd, get_subprocess_cmd_exit,
                                         start_subprocess_cmd)

    # Brief, out-of-context, examples:
    std_output, std_error = execute_subprocess_cmd(['echo', 'HOBO!'])
    exit_code = get_subprocess_cmd_exit(['systemctl', 'status', 'sshd'])
    popen_obj = start_subprocess_cmd(list_of_cmds, set_cwd=set_cwd)
    popen_obj.communicate()
"""

# Standard Imports
from typing import Tuple
import subprocess
# Third Party Imports
# Local Imports
from hobo.validation import validate_list, validate_string


def execute_subprocess_cmd(list_of_cmds: list, set_cwd: str = None) -> Tuple[str, str]:
    """Executes a set of commands using subprocess' Popen.

    Differs from get_subprocess_cmd_exit() in that this function returns the output, not the exit
    code. start_subprocess_cmd() is used under the hood and handles input validation. This function
    makes no assumptions about the results. All exceptions are allowed to bubble up. No output is
    printed.

    Args:
        list_of_cmds: A list of commands to execute in subprocess.
        set_cwd: Optional; Passed to subprocess.Popen() as the cwd keyword argument.

    Returns:
        A tuple containing stdout and stderr.

    Raises:
        RuntimeError: An error occurs during run-time.
    """
    # LOCAL VARIABLES
    std_output = ''  # Capture the output
    std_error = ''  # Capture the errors

    # COMPLETE PROCESS
    process = start_subprocess_cmd(list_of_cmds, set_cwd=set_cwd)
    (std_output, std_error) = process.communicate()

    return tuple((std_output, std_error))


def get_subprocess_cmd_exit(list_of_cmds: list, set_cwd: str = None) -> int:
    """Executes a set of commands using subprocess' Popen.

    Differs from execute_subprocess_cmd() in that this function returns the exit code, not the
    output. start_subprocess_cmd() is used under the hood and handles input validation. This
    function makes no assumptions about the results. All exceptions are allowed to bubble up.
    No output is printed.

    Args:
        list_of_cmds: A list of commands to execute in subprocess.
        set_cwd: Optional; Passed to subprocess.Popen() as the cwd keyword argument.


    Returns:
        An integer representing the exit code.

    Raises:
        RuntimeError: An error occurs during run-time.
    """
    # COMPLETE PROCESS
    process = start_subprocess_cmd(list_of_cmds, set_cwd=set_cwd)
    process.communicate()
    return process.returncode


def start_subprocess_cmd(list_of_cmds: list, set_cwd: str = None) -> subprocess.Popen:
    """Instantiates a Popen object.

    Instantiates a Popen object given a set of commands. This function does not call the
    communicate() method.

    Args:
        list_of_cmds: A list of commands to execute in subprocess.
        set_cwd: Optional; Passed to subprocess.Popen() as the cwd keyword argument.

    Returns:
        A Popen object.

    Raises:
        RuntimeError: An error occurs during run-time.
        TypeError: list_of_cmds is not a list or contains a non-string.
        ValueError: list_of_cmds is empty or contains an empty command.
    """
    # LOCAL VARIABLES
    process = None  # Popen object

    # INPUT VALIDATION
    # list_of_cmds
    validate_list(list_of_cmds, 'list_of_cmds', can_be_empty=False)
    for command in list_of_cmds:
        validate_string(command, 'list_of_cmds entry', can_be_empty=False)
    # set_cwd
    if set_cwd:
        validate_string(set_cwd, 'set_cwd')

    # START PROCESS
    # pylint: disable=consider-using-with
    process = subprocess.Popen(list_of_cmds, cwd=set_cwd,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               universal_newlines=True)

    # DONE
    if not process:
        raise RuntimeError('Popen failed without raising an Exception')
    return process
