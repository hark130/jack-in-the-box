"""Automates the execution of Makefile rules using subprocess.

This module defines functions dedicated to wrapping and/or automating the execution of Makefile
rules using Python's subprocess module.  These functions are essentially wrappers around the
MakefileRule class, as defined in makefile_rule.py.

    Typical usage example:

    from hobo.makefile_automation import install_binary
    from hobo.makefile_rule import MakefileRule


    clean_rule = MakefileRule(makefile_filename='Makefile', makefile_rule='clean')
    build_rule = MakefileRule(makefile_filename='Makefile', makefile_rule='build')
    install_rule = MakefileRule(makefile_filename='Makefile', makefile_rule='install',
                                as_root=True)
    install_binary(clean_rule, build_rule, install_rule)
"""

# Standard Imports
# Third Party Imports
# Local Imports
from hobo.makefile_rule import MakefileRule
from hobo.validation import validate_type


def execute_makefile_rule(makefile_filename: str, makefile_rule: str, as_root: bool = False,
                          options: list = None, verify_rule: bool = True) -> None:
    """Executes a Makefile rule.

    This function has been refactored to utilize the MakefileRule class.  Takes all configurations
    necessary to validate, verify and execute a single Makefile rule using subprocess.

    Args:
        makefile_filename: The relative or absolute filename to the Makefile being used.
        recipe: The name of the Makefile rule being verified and executed.
        as_root: Optional; If True, executes rule with root privileges
        options: Optional; A list of non-empty strings to append to the rule during execution.
        verify_rule: Optional; If True, verifies makefile_rule exists within makefile_filename.

    Raises:
        FileNotFoundError: Makefile doesn't exist.
        OSError: Makefile is not a file.
        RuntimeError: 'root' privileges are required but missing, the recipe is missing from the
            Makefile, or the Makefile rule provided errors.
        TypeError: Invalid data type.
        ValueError: Invalid value.
    """
    makefile_rule = MakefileRule(makefile_filename=makefile_filename, makefile_rule=makefile_rule,
                                 as_root=as_root, options=options, verify_rule=verify_rule)
    _execute_makefile_rule(makefile_rule)


def install_binary(clean_obj: MakefileRule, build_obj: MakefileRule,
                   install_obj: MakefileRule) -> None:
    """Executes common Makefile rules.

    Executes 'clean', 'build', and 'install' Makefile rules, in that order, as specified by the
    Makefile object.  A rule will be skipped if it's set to None.

    Args:
        clean_obj: MakefileRule object defining the 'clean' Makefile rule.
        build_obj: MakefileRule object defining the 'build' Makefile rule.
        install_obj: MakefileRule object defining the 'install' Makefile rule.

    Raises:
        FileNotFoundError: Makefile doesn't exist.
        OSError: Makefile is not a file.
        RuntimeError: All three arguments are None.  (Why did you even call this function?!)
        RuntimeError: 'root' privileges are required but missing or the rule is missing from
            the Makefile.
        TypeError: Invalid data type.
        ValueError: Invalid value.
    """
    # INPUT VALIDATION
    if clean_obj:
        validate_type(clean_obj, 'clean_obj', MakefileRule)
    if build_obj:
        validate_type(build_obj, 'build_obj', MakefileRule)
    if install_obj:
        validate_type(install_obj, 'install_obj', MakefileRule)
    if not clean_obj and not build_obj and not install_obj:
        raise RuntimeError('At least one of the arguments must contain an object')

    # VALIDATE AND EXECUTE
    _execute_makefile_rule(clean_obj)
    _execute_makefile_rule(build_obj)
    _execute_makefile_rule(install_obj)


def uninstall_binary(uninstall_rule: MakefileRule) -> None:
    """Executes an uninstall Makefile rule.

    Executes the provided Makefile object intended to uninstall a binary using a Makefile rule.

    Args:
        uninstall_rule: MakefileRule object defining the 'uninstall' Makefile rule.

    Raises:
        FileNotFoundError: Makefile doesn't exist.
        OSError: Makefile is not a file.
        RuntimeError: 'root' privileges are required but missing or the rule is missing from
            the Makefile.
        TypeError: Invalid data type.
        ValueError: Invalid value.
    """
    validate_type(uninstall_rule, 'uninstall_rule', MakefileRule)
    _execute_makefile_rule(uninstall_rule)


#############################
# INTERNAL HELPER FUNCTIONS #
#############################


def _execute_makefile_rule(makefile_rule: MakefileRule) -> None:
    """Verifies and executes one Makefile rule.

    Executes a single Makefile as specified by makefile_rule.  makefile_rule will be ignored
    if None.  Explicitly calls verify() and execute() methods of the Makefile object.

    Args:
        makefile_rule: MakefileRule object to verify and execute.

    Raises:
        FileNotFoundError: Makefile doesn't exist.
        OSError: Makefile is not a file.
        RuntimeError: 'root' privileges are required but missing or the rule is missing from
            the Makefile.
        TypeError: Invalid data type.
        ValueError: Invalid value.
    """
    if makefile_rule:
        makefile_rule.verify()
        makefile_rule.execute()
